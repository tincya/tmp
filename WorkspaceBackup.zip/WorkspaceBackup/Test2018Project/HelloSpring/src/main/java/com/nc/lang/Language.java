package com.nc.lang;

public interface Language {
	public String getGreeting();
	public String getBye();
}
