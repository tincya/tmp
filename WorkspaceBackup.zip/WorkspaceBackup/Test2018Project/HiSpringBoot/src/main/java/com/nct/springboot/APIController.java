package com.nct.springboot;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class APIController {
	@RequestMapping("/test2")
	public String test2() {return "test2";}
}