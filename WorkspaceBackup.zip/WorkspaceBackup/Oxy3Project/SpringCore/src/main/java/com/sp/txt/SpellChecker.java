package com.sp.txt;

public class SpellChecker {
    public SpellChecker() {
        System.out.println("Init Checker.");
    }
    public void checkSpelling() {
        System.out.println("Checking...");
    }
}